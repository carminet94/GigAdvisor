<?php
require "conn.php";

$mysql_queryCoordinate = "SELECT latitudine,longitudine FROM `reviews`";
$resultCoordinate = mysqli_query($conn,$mysql_queryCoordinate);

$contCoordinate = mysqli_num_rows($resultCoordinate);

$responseCoordinate=array();

if($contCoordinate>0){

    while ($rowCoordinate = mysqli_fetch_assoc($resultCoordinate)) {
        $responseCoordinate[] = $rowCoordinate;
    }

}
else{
	echo"Tabella vuota";
}

echo json_encode(array("Coordinate"=>$responseCoordinate));
?>