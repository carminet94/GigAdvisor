<?php
require "conn.php";
$username=$_POST["username"];
$password=$_POST["password"];
$hash_pass = md5($password);

$sql = "select * from users where username='$username' and password='$hash_pass'";
    
$result = mysqli_query($conn,$sql);
$cont = mysqli_num_rows($result);

$response=array();
if($cont>0){

    while ($row = mysqli_fetch_assoc($result)) {
        $response[] = $row;
    }

}
else{
	echo"Tabella vuota";
}

echo json_encode(array("login"=>$response));

?>
