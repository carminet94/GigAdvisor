<?php
/**
 * Loads all extensions custom auto-loaders.
 *
 * This file has been auto-generated
 * by phpBB while loading the extensions.
 */

