<?php exit; ?>
1582044249
SELECT * FROM phpbb_styles s WHERE s.style_id = 1
283
a:1:{i:0;a:8:{s:8:"style_id";s:1:"1";s:10:"style_name";s:9:"prosilver";s:15:"style_copyright";s:20:"&copy; phpBB Limited";s:12:"style_active";s:1:"1";s:10:"style_path";s:9:"prosilver";s:15:"bbcode_bitfield";s:4:"//g=";s:15:"style_parent_id";s:1:"0";s:17:"style_parent_tree";s:0:"";}}