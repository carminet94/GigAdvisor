<?php
require "conn.php";

$mysql_query = "select CAST(AVG(SAW) AS DECIMAL(10,2)) AS SAW, 
                       CAST(AVG(CT) AS DECIMAL(10,2)) AS CT, 
                       CAST(AVG(PTL) AS DECIMAL(10,2)) AS PTL, 
                       CAST(AVG(PF) AS DECIMAL(10,2)) AS PF
    from reviews,platform where reviews.platform_id = platform.id and nome='Uber';";
    
$mysql_query2 = "select CAST(AVG(SAW) AS DECIMAL(10,2)) AS SAW, 
                       CAST(AVG(CT) AS DECIMAL(10,2)) AS CT, 
                       CAST(AVG(PTL) AS DECIMAL(10,2)) AS PTL, 
                       CAST(AVG(PF) AS DECIMAL(10,2)) AS PF
    from reviews,platform where reviews.platform_id = platform.id and nome='UpWork';";
    
$result = mysqli_query($conn,$mysql_query);
$cont = mysqli_num_rows($result);

$result2 = mysqli_query($conn,$mysql_query2);
$cont2 = mysqli_num_rows($result2);

$response=array();
$response2=array();

if($cont>0 && $cont2>0){

    while ($row = mysqli_fetch_assoc($result)) {
        $response[] = $row;
    }
    
    while ($row2 = mysqli_fetch_assoc($result2)) {
        $response2[] = $row2;
    }

}
else{
	echo"Tabella vuota";
}

echo json_encode(array("Uber"=>$response,"UpWork"=>$response2));

?>