<?php
$servername = "localhost";
$username = "id12056183_gigadvisor";
$password = "gigadvisor";
$database = "id12056183_gigadvisor";

$conn = mysqli_connect($servername,$username,$password,$database);

/*if($conn){
    echo"Connesso";
}else{
    echo"Non Connesso";
}*/

?>