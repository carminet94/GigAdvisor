
<html>
<div id="anychart-embed-countries-italy" class="anychart-embed anychart-embed-countries-italy">
<script src="https://cdn.anychart.com/releases/v8/js/anychart-base.min.js"></script>
<script src="https://cdn.anychart.com/releases/v8/js/anychart-map.min.js"></script>
<script src="https://cdn.anychart.com/releases/v8/js/anychart-exports.min.js"></script>
<script src="https://cdn.anychart.com/releases/v8/js/anychart-ui.min.js"></script>
<script src="https://cdn.anychart.com/releases/v8/geodata/countries/italy/italy.js"></script>
<div id="ac_style_countries-italy" style="display:none;">
html, body, #container {
    width: 100%;
    height: 100%;
    margin-top: 25px;
    padding: 0;
}
</div>
<script>(function(){
function ac_add_to_head(el){
	var head = document.getElementsByTagName('head')[0];
	head.insertBefore(el,head.firstChild);
}
function ac_add_link(url){
	var el = document.createElement('link');
	el.rel='stylesheet';el.type='text/css';el.media='all';el.href=url;
	ac_add_to_head(el);
}
function ac_add_style(css){
	var ac_style = document.createElement('style');
	if (ac_style.styleSheet) ac_style.styleSheet.cssText = css;
	else ac_style.appendChild(document.createTextNode(css));
	ac_add_to_head(ac_style);
}
ac_add_link('https://cdn.anychart.com/releases/v8/css/anychart-ui.min.css');
ac_add_style(document.getElementById("ac_style_countries-italy").innerHTML);
ac_add_style(".anychart-embed-countries-italy{width:400px;height:450px;}");
})();</script>
<div id="container"> 
	<script type="text/javascript">
		//funzione per l'autocompletamento degli input text

$(document).ready(function() { 
        $.ajax({  
          type: "GET",
          url: "includes/lista_pizzerie.php",
          // definisco il formato della risposta
          dataType: "json",  
          success: function(lista_pizzerie) {  
            $( "#tags" ).autocomplete({
      			source: lista_pizzerie
   			 });
          },
          error: function(){
          	console.log("no");
          }
    });
  } );
	</script>
	
</div>
<script>
anychart.onDocumentReady(function() {
    // create map
    map = anychart.map();

    // create data set
    var dataSet = anychart.data.set([
		{'id': 'IT.MO', 'value': 0},
		{'id': 'IT.RE', 'value': 1},
		{'id': 'IT.PR', 'value': 2},
		{'id': 'IT.PC', 'value': 3},
		{'id': 'IT.BO', 'value': 4},
		{'id': 'IT.FE', 'value': 5},
		{'id': 'IT.RA', 'value': 6},
		{'id': 'IT.FC', 'value': 7},
		{'id': 'IT.RN', 'value': 8},
		{'id': 'IT.GE', 'value': 9},
		{'id': 'IT.SV', 'value': 10},
		{'id': 'IT.IM', 'value': 11},
		{'id': 'IT.SP', 'value': 12},
		{'id': 'IT.CI', 'value': 13},
		{'id': 'IT.VS', 'value': 14},
		{'id': 'IT.OR', 'value': 15},
		{'id': 'IT.SS', 'value': 16},
		{'id': 'IT.OT', 'value': 17},
		{'id': 'IT.NU', 'value': 18},
		{'id': 'IT.OG', 'value': 19},
		{'id': 'IT.CA', 'value': 20},
		{'id': 'IT.GR', 'value': 21},
		{'id': 'IT.LI', 'value': 22},
		{'id': 'IT.PI', 'value': 23},
		{'id': 'IT.MS', 'value': 24},
		{'id': 'IT.LU', 'value': 25},
		{'id': 'IT.PT', 'value': 26},
		{'id': 'IT.PO', 'value': 27},
		{'id': 'IT.FI', 'value': 28},
		{'id': 'IT.AR', 'value': 29},
		{'id': 'IT.SI', 'value': 30},
		{'id': 'IT.MT', 'value': 31},
		{'id': 'IT.PZ', 'value': 32},
		{'id': 'IT.CS', 'value': 33},
		{'id': 'IT.KR', 'value': 34},
		{'id': 'IT.CZ', 'value': 35},
		{'id': 'IT.VV', 'value': 36},
		{'id': 'IT.RC', 'value': 37},
		{'id': 'IT.CE', 'value': 38},
		{'id': 'IT.NA', 'value': 39},
		{'id': 'IT.BN', 'value': 40},
		{'id': 'IT.AV', 'value': 41},
		{'id': 'IT.SA', 'value': 42},
		{'id': 'IT.CB', 'value': 43},
		{'id': 'IT.IS', 'value': 44},
		{'id': 'IT.BA', 'value': 45},
		{'id': 'IT.FG', 'value': 46},
		{'id': 'IT.BT', 'value': 47},
		{'id': 'IT.BR', 'value': 48},
		{'id': 'IT.LE', 'value': 49},
		{'id': 'IT.TA', 'value': 50},
		{'id': 'IT.TP', 'value': 51},
		{'id': 'IT.PA', 'value': 52},
		{'id': 'IT.ME', 'value': 53},
		{'id': 'IT.EN', 'value': 54},
		{'id': 'IT.CT', 'value': 55},
		{'id': 'IT.SR', 'value': 56},
		{'id': 'IT.RG', 'value': 57},
		{'id': 'IT.CL', 'value': 58},
		{'id': 'IT.AG', 'value': 59},
		{'id': 'IT.PE', 'value': 60},
		{'id': 'IT.TE', 'value': 61},
		{'id': 'IT.AQ', 'value': 62},
		{'id': 'IT.CH', 'value': 63},
		{'id': 'IT.RM', 'value': 64},
		{'id': 'IT.VT', 'value': 65},
		{'id': 'IT.RI', 'value': 66},
		{'id': 'IT.FR', 'value': 67},
		{'id': 'IT.LT', 'value': 68},
		{'id': 'IT.AN', 'value': 69},
		{'id': 'IT.PU', 'value': 70},
		{'id': 'IT.MC', 'value': 71},
		{'id': 'IT.FM', 'value': 72},
		{'id': 'IT.AP', 'value': 73},
		{'id': 'IT.PG', 'value': 74},
		{'id': 'IT.TR', 'value': 75},
		{'id': 'IT.TO', 'value': 76},
		{'id': 'IT.BI', 'value': 77},
		{'id': 'IT.VC', 'value': 78},
		{'id': 'IT.VB', 'value': 79},
		{'id': 'IT.NO', 'value': 80},
		{'id': 'IT.AL', 'value': 81},
		{'id': 'IT.AT', 'value': 82},
		{'id': 'IT.CN', 'value': 83},
		{'id': 'IT.AO', 'value': 84},
		{'id': 'IT.BG', 'value': 85},
		{'id': 'IT.SO', 'value': 86},
		{'id': 'IT.BS', 'value': 87},
		{'id': 'IT.MN', 'value': 88},
		{'id': 'IT.CR', 'value': 89},
		{'id': 'IT.LO', 'value': 90},
		{'id': 'IT.PV', 'value': 91},
		{'id': 'IT.MI', 'value': 92},
		{'id': 'IT.VA', 'value': 93},
		{'id': 'IT.CO', 'value': 94},
		{'id': 'IT.LC', 'value': 95},
		{'id': 'IT.MB', 'value': 96},
		{'id': 'IT.UD', 'value': 97},
		{'id': 'IT.PN', 'value': 98},
		{'id': 'IT.GO', 'value': 99},
		{'id': 'IT.TS', 'value': 100},
		{'id': 'IT.BZ', 'value': 101},
		{'id': 'IT.TN', 'value': 102},
		{'id': 'IT.VE', 'value': 103},
		{'id': 'IT.RO', 'value': 104},
		{'id': 'IT.PD', 'value': 105},
		{'id': 'IT.VR', 'value': 106},
		{'id': 'IT.VI', 'value': 107},
		{'id': 'IT.TV', 'value': 108},
		{'id': 'IT.BL', 'value': 109}
    ]);

    // create choropleth series
    series = map.choropleth(dataSet);

    // set geoIdField to 'id', this field contains in geo data meta properties
    series.geoIdField('id');

    // set map color settings
    series.colorScale(anychart.scales.linearColor('#c72424', '#deebf7'));
    series.hovered().fill('#addd8e');

    // set geo data, you can find this map in our geo maps collection
    // https://cdn.anychart.com/#maps-collection
    map.geoData(anychart.maps['italy']);

    //set map container id (div)
    map.container('container');

    //initiate map drawing
    map.draw();
});
</script>
<form action="mappa.php" method="POST"  >
		<input type="search" name="provincia" placeholder="Ricerca Provincia" required>
		<input type="submit" value="Invia">
	</form><br/><br/>
	<?php
		require "conn.php";
		if(isset($_POST['provincia'])){
				$provincia= @$_POST["provincia"];
				//query per prendere nome della foto nel server x cancellarla
				$query="SELECT valore from mappa WHERE provincia='$provincia'";
				// esecuzione della query
				$result = mysqli_query($conn,$query);
                $cont = mysqli_num_rows($result);
				//se la tabella Ã¨ vuota lo stampo a video
				if($cont==0)
				{
				 echo "La provincia $provincia non esiste! ";
				}
				else{
					//recupero il contenuto di ogni record trovato
					$resrow=mysqli_fetch_array($result);
					$valore_provincia=$resrow[0];
					echo"Provincia: $provincia - Valore: $valore_provincia";
				}
		}

	?>
</div>
</html>