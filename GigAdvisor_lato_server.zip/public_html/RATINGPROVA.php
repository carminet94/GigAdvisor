<?php
require "conn.php";

$mysql_query = "SELECT SAW FROM reviews WHERE reviews.platform_id='5' ORDER BY reviews.data DESC;";
    
$result = mysqli_query($conn,$mysql_query);
$cont = mysqli_num_rows($result);

$response=array();
if($cont>0){

    while ($row = mysqli_fetch_assoc($result)) {
        $response[] = $row;
    }

}
else{
	echo"Tabella vuota";
}

echo json_encode(array("TrendUberSAW"=>$response));

?>