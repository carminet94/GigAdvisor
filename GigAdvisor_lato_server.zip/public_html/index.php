<html>
	<head>
		<title>
			
		</title>
	<head>
		<style type="text/css">
			.form{
				margin: 5vh 5vw;
				border: 2px solid grey;
				width: 300px;
				padding: 5px;
			}
			.form p{
				width: 100%;
				margin: 5px;
				text-align: center;
			}
			.form input{
				width: 100%;
				margin: 5px 0;
			}
		</style>
	<body>
		<?php
			$username=@$_POST["username"];
			$password=@$_POST["password"];
			if ($username!="carmine" and $password!="tramontano") {
		?>

		<form class="form" action="index.php" method="post">
			<p>LOGIN</p>
			<input type="text" name="username" placeholder="Username" required>
			<input type="password" name="password" placeholder="Password" required>
			<input type="submit" value="Accedi"/>
		</form>
		<?php
			}
			else{
		?>
		<a href="">Link </a><br>
		<a href="">Link </a><br>
		<a href="">Link </a><br>
		<a href="">Link </a><br>
		<a href="">Link </a><br>
		<a href="">Link </a><br>
		<a href="">Link </a><br>
		<a href="">Link </a><br>
		<a href="">Link </a><br>
		<a href="">Link </a><br>
		<a href="">Link </a><br>
		<?php
			}
		?>

	</body>
</html>