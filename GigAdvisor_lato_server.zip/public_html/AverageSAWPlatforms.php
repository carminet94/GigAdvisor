<?php
require "conn.php";

$mysql_queryAmazon = "SELECT AVG(SAW) AS AVERAGE_SAW_AMAZON FROM `reviews` WHERE platform_id='1'";
$mysql_queryFoodora = "SELECT AVG(SAW) AS AVERAGE_SAW_FOODORA FROM `reviews` WHERE platform_id='2'";
$mysql_queryJustEat = "SELECT AVG(SAW) AS AVERAGE_SAW_JUSTEAT FROM `reviews` WHERE platform_id='3'";
$mysql_queryDeliveroo = "SELECT AVG(SAW) AS AVERAGE_SAW_DELIVEROO FROM `reviews` WHERE platform_id='4'";
$mysql_queryUber = "SELECT AVG(SAW) AS AVERAGE_SAW_UBER FROM `reviews` WHERE platform_id='5'";
$mysql_queryUpWork = "SELECT AVG(SAW) AS AVERAGE_SAW_UPWORK FROM `reviews` WHERE platform_id='6'";

$resultAmazon = mysqli_query($conn,$mysql_queryAmazon);
$resultFoodora = mysqli_query($conn,$mysql_queryFoodora);
$resultJustEat = mysqli_query($conn,$mysql_queryJustEat);
$resultDeliveroo = mysqli_query($conn,$mysql_queryDeliveroo);
$resultUber = mysqli_query($conn,$mysql_queryUber);
$resultUpWork = mysqli_query($conn,$mysql_queryUpWork);


$contAmazon = mysqli_num_rows($resultAmazon);
$contFoodora = mysqli_num_rows($resultFoodora);
$contJustEat = mysqli_num_rows($resultJustEat);
$contDeliveroo = mysqli_num_rows($resultDeliveroo);
$contUber = mysqli_num_rows($resultUber);
$contUpWork = mysqli_num_rows($resultUpWork);

$responseAmazon=array();
$responseFoodora=array();
$responseJustEat =array();
$responseDeliveroo=array();
$responseUber =array();
$responseUpWork =array();

if($contAmazon>0 && $contFoodora>0 && $contJustEat>0 && $contDeliveroo>0 && $contUber>0 && $contUpWork>0){

    while ($rowAmazon = mysqli_fetch_assoc($resultAmazon)) {
        $responseAmazon[] = $rowAmazon;
    }
    while ($rowFoodora = mysqli_fetch_assoc($resultFoodora)) {
        $responseFoodora[] = $rowFoodora;
    }
    while ($rowJustEat = mysqli_fetch_assoc($resultJustEat)) {
        $responseJustEat[] = $rowJustEat;
    }
    while ($rowDeliveroo = mysqli_fetch_assoc($resultDeliveroo)) {
        $responseDeliveroo[] = $rowDeliveroo;
    }
    while ($rowUber = mysqli_fetch_assoc($resultUber)) {
        $responseUber[] = $rowUber;
    }
    while ($rowUpWork = mysqli_fetch_assoc($resultUpWork)) {
        $responseUpWork[] = $rowUpWork;
    }
    

}
else{
	echo"Tabella vuota";
}

echo json_encode(array("AverageSawAmazon"=>$responseAmazon,"AverageSawFoodora"=>$responseFoodora,
                        "AverageSawJustEat"=>$responseJustEat,"AverageDeliveroo"=>$responseDeliveroo,
                        "AverageSawUber"=>$responseUber,"AverageUpWork"=>$responseUpWork));

?>