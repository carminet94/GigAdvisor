<?php
require "conn.php";

$mysql_queryFoodora = "select (AVG(SAW)+ AVG(CT)+ AVG(PTL)+ AVG(PF))/4 as RATING_FOODORA
                from reviews,platform where reviews.platform_id = platform.id and platform.id='2' ";

$resultFoodora = mysqli_query($conn,$mysql_queryFoodora);
$contFoodora = mysqli_num_rows($resultFoodora);

$responseFoodora=array();

if($contFoodora>0){

    while ($rowFoodora = mysqli_fetch_assoc($resultFoodora)) {
        $responseFoodora[] = $rowFoodora;
    }

}
else{
	echo"Tabella vuota";
}

echo json_encode(array("Foodora"=>$responseFoodora));

?>