<?php
require "conn.php";

$mysql_queryUber = "select (AVG(SAW)+ AVG(CT)+ AVG(PTL)+ AVG(PF))/4 as RATING_UBER 
                from reviews,platform where reviews.platform_id = platform.id and platform.id='5' ";
    
$resultUber = mysqli_query($conn,$mysql_queryUber);
$contUber = mysqli_num_rows($resultUber);

$responseUber=array();

if($contUber>0){
    
    while ($rowUber = mysqli_fetch_assoc($resultUber)) {
        $responseUber[] = $rowUber;
    }

}
else{
	echo"Tabella vuota";
}

echo json_encode(array("Uber"=>$responseUber));

?>