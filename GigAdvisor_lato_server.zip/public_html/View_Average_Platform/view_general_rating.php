<?php
require "conn.php";

$mysql_query1 = "select (AVG(SAW)+ AVG(CT)+ AVG(PTL)+ AVG(PF))/4 as RATING_AMAZON
                from reviews,platform where reviews.platform_id = platform.id and platform.id='1' ";
$mysql_query2= "select (AVG(SAW)+ AVG(CT)+ AVG(PTL)+ AVG(PF))/4 as RATING_FOODORA
                from reviews,platform where reviews.platform_id = platform.id and platform.id='2' ";
$mysql_query3 = "select (AVG(SAW)+ AVG(CT)+ AVG(PTL)+ AVG(PF))/4 as RATING_JUSTEAT
                from reviews,platform where reviews.platform_id = platform.id and platform.id='3' ";
$mysql_query4 = "select (AVG(SAW)+ AVG(CT)+ AVG(PTL)+ AVG(PF))/4 as RATING_DELIVEROO
                from reviews,platform where reviews.platform_id = platform.id and platform.id='4' ";
$mysql_query5 = "select (AVG(SAW)+ AVG(CT)+ AVG(PTL)+ AVG(PF))/4 as RATING_UBER
                from reviews,platform where reviews.platform_id = platform.id and platform.id='5' ";
$mysql_query6 = "select (AVG(SAW)+ AVG(CT)+ AVG(PTL)+ AVG(PF))/4 as RATING_UPWORK
                from reviews,platform where reviews.platform_id = platform.id and platform.id='6' ";

$result1 = mysqli_query($conn,$mysql_query1);
$result2 = mysqli_query($conn,$mysql_query2);
$result3 = mysqli_query($conn,$mysql_query3);
$result4 = mysqli_query($conn,$mysql_query4);
$result5 = mysqli_query($conn,$mysql_query5);
$result6=  mysqli_query($conn,$mysql_query6);


$cont1 = mysqli_num_rows($result1);
$cont2 = mysqli_num_rows($result2);
$cont3 = mysqli_num_rows($result3);
$cont4 = mysqli_num_rows($result4);
$cont5 = mysqli_num_rows($result5);
$cont6 = mysqli_num_rows($result6);

$response1=array();
$response2=array();
$response3=array();
$response4=array();
$response5=array();
$response6=array();

if($cont1>0 && $cont2>0 && $cont3>0 && $cont4>0 && $cont5>0 && $cont6>0 ){

        while ($row1 = mysqli_fetch_assoc($result1)) {
            $response1[] = $row1;
        }
        while ($row2 = mysqli_fetch_assoc($result2)) {
        $response2[] = $row2;
        }
        while ($row3 = mysqli_fetch_assoc($result3)) {
        $response3[] = $row3;
        }
        while ($row4 = mysqli_fetch_assoc($result4)) {
        $response4[] = $row4;
        }
        while ($row5 = mysqli_fetch_assoc($result5)) {
        $response5[] = $row5;
        }
        while ($row6 = mysqli_fetch_assoc($result6)) {
        $response6[] = $row6;
        }

}
else{
	echo"Tabella vuota";
}

echo json_encode($response1);
echo json_encode($response2);
echo json_encode($response3);
echo json_encode($response4);
echo json_encode($response5);
echo json_encode($response6);

?>