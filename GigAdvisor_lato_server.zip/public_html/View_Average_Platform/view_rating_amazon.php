<?php
require "conn.php";

$mysql_queryAmazon = "select (AVG(SAW)+ AVG(CT)+ AVG(PTL)+ AVG(PF))/4 as RATING_AMAZON
                from reviews,platform where reviews.platform_id = platform.id and platform.id='1' ";

$resultAmazon = mysqli_query($conn,$mysql_queryAmazon);
$contAmazon = mysqli_num_rows($resultAmazon);

$responseAmazon=array();

if($contAmazon>0){

    while ($rowAmazon = mysqli_fetch_assoc($resultAmazon)) {
        $responseAmazon[] = $rowAmazon;
    }

}
else{
	echo"Tabella vuota";
}

echo json_encode(array("Amazon"=>$responseAmazon));

?>