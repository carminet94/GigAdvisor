<?php
require "conn.php";

$mysql_queryUpWrok = "select (AVG(SAW)+ AVG(CT)+ AVG(PTL)+ AVG(PF))/4 as RATING_UPWORK
                from reviews,platform where reviews.platform_id = platform.id and platform.id='6' ";
    
$resultUpWrok = mysqli_query($conn,$mysql_queryUpWrok);
$contUpWrok = mysqli_num_rows($resultUpWrok);

$responseUpWrok=array();

if($contUpWrok>0){
    
    while ($rowUpWrok = mysqli_fetch_assoc($resultUpWrok)) {
        $responseUpWrok[] = $rowUpWrok;
    }

}
else{
	echo"Tabella vuota";
}

echo json_encode(array("UpWork"=>$responseUpWrok));

?>