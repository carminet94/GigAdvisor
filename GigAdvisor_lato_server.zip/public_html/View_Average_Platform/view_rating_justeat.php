<?php
require "conn.php";

$mysql_queryJustEat = "select (AVG(SAW)+ AVG(CT)+ AVG(PTL)+ AVG(PF))/4 as RATING_JUSTEAT
                from reviews,platform where reviews.platform_id = platform.id and platform.id='3' ";
    
$resultJustEat = mysqli_query($conn,$mysql_queryJustEat);
$contJustEat = mysqli_num_rows($resultJustEat);

$responseJustEat=array();

if($contJustEat>0){
    
    while ($rowJustEat = mysqli_fetch_assoc($resultJustEat)) {
        $responseJustEat[] = $rowJustEat;
    }

}
else{
	echo"Tabella vuota";
}

echo json_encode(array("JustEat"=>$responseJustEat));

?>