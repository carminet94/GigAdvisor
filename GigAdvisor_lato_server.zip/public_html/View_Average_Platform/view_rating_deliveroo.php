<?php
require "conn.php";

$mysql_queryDeliveroo = "select (AVG(SAW)+ AVG(CT)+ AVG(PTL)+ AVG(PF))/4 as RATING_DELIVEROO
                from reviews,platform where reviews.platform_id = platform.id and platform.id='4' ";
    
$resultDeliveroo = mysqli_query($conn,$mysql_queryDeliveroo);
$contDeliveroo = mysqli_num_rows($resultDeliveroo);

$responseDeliveroo=array();

if($contDeliveroo>0){
    
    while ($rowDeliveroo = mysqli_fetch_assoc($resultDeliveroo)) {
        $responseDeliveroo[] = $rowDeliveroo;
    }

}
else{
	echo"Tabella vuota";
}

echo json_encode(array("Deliveroo"=>$responseDeliveroo));

?>