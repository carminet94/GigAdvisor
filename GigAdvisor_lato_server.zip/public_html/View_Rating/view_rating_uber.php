<?php
require "conn.php";

$mysql_query = "select titolo,data,descrizione,nome from reviews,platform where reviews.platform_id = platform.id and nome='Uber' order by data DESC;";
    
$result = mysqli_query($conn,$mysql_query);
$cont = mysqli_num_rows($result);

$response=array();
if($cont>0){

    while ($row = mysqli_fetch_assoc($result)) {
        $response[] = $row;
    }

}
else{
	echo"Tabella vuota";
}

echo json_encode(array("ViewUber"=>$response));

?>