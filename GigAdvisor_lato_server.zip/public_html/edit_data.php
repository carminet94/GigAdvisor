<?php
        require "conn.php";
        $nome = $_POST["nome"];
        $username = $_POST["username"];
        $id = $_POST["id"];
        
        $sql = "UPDATE users SET nome='$nome' , username='$username' where id='$id' ";

        if(mysqli_query($conn,$sql)){
            
                $result["success"] = "1";
        		$result["message"] = "success";
        		
        		echo json_encode($result);
        		mysqli_close($conn);
        		
        } else {

        		$result["success"] = "0";
        		$result["message"] = "error";
        
        		echo json_encode($result);
        		mysqli_close($conn);
	        }

?>